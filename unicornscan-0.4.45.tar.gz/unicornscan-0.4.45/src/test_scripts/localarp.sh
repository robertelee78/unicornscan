#!/bin/sh -x

unicornscan -mA -Iv gateway/24
