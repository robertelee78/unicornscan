#ifndef _PAYLOAD_H
# define _PAYLOAD_H

#define PAY_DANGEROUS 0x01

#endif
