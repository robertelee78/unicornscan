/**********************************************************************
 * Copyright (C) 2004-2006 (Jack Louis) <jack@rapturesecurity.org>    *
 *                                                                    *
 * This program is free software; you can redistribute it and/or      *
 * modify it under the terms of the GNU General Public License        *
 * as published by the Free Software Foundation; either               *
 * version 2 of the License, or (at your option) any later            *
 * version.                                                           *
 *                                                                    *
 * This program is distributed in the hope that it will be useful,    *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of     *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the      *
 * GNU General Public License for more details.                       *
 *                                                                    *
 * You should have received a copy of the GNU General Public License  *
 * along with this program; if not, write to the Free Software        *
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.          *
 **********************************************************************/
#ifndef _NEWPARSE_H
# define _NEWPARSE_H

#include <pcap.h>

void parse_packet(uint8_t *, const struct pcap_pkthdr * /* phdr */, const uint8_t * /* packet */);

void decode_tcpopts(const uint8_t * /* data */, size_t /* len */);
void decode_ipopts (const uint8_t * /* data */, size_t /* len */);

/* Statistics for malformed/skipped packets */
void packet_parse_print_stats(void);
void packet_parse_reset_stats(void);

#endif
